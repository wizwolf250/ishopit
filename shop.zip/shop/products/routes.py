import datetime
from flask import Blueprint
from flask import url_for, redirect, render_template, request, session, abort, flash, Flask
from flask import current_app as app

from markupsafe import escape
from shop.models import Item, Cart, Order, Review, Category

from flask_login import current_user, login_required

product_bp = Blueprint(
    'product_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

@product_bp.route('/item/<int:id>')
@login_required
def item(id):
	item = Item.query.filter_by(id=id).first()
	colors = item.colors
	cart_item = Cart.query.filter_by(itemid=item.id, uid=current_user.id).first()
	quantity = 1
	reviews = Review.query.filter_by(itemid=item.id).all()
	
	if cart_item:
	    quantity = cart_item.quantity
	    
	return render_template('item.html', item=item, reviews=reviews, title="Detail", colors=colors, quantity=quantity)

@product_bp.route("/popural")
def popural():
	items = Item.query.all()
	return render_template("popural.html", items=items)
	
@product_bp.route("/categories")
def categories():
	categories = Category.query.all()
	items = Item.query.all()
	return render_template("categories.html", title="Categories", items=items, categories=categories)