import os
import unittest
from flask import current_app
from shop.app import create_app
from shop.utils.db import db
from shop.models import *

class TestApp(unittest.TestCase):
    def setUp(self):
        self.app = create_app("TEST")
        self.app.config["WTF_CSRF_ENABLED"] = False
        self.appctx = self.app.app_context()
        self.appctx.push()
        db.create_all()
        self.populate_db()
        self.client = self.app.test_client()
        
        
    def tearDown(self):
        db.drop_all()
        self.appctx.pop()
        self.app = None
        self.appctx = None
        self.client = None
        
    def test_app(self):
        assert self.app is not None
        assert current_app == self.app
        
    def test_home_page_redirect(self):
        response = self.client.get("/", follow_redirects=True)
        assert response.status_code == 200
        assert response.request.path == "/login"

    def test_registration_page_user(self):
    	response = self.client.post("/auth/register", data={"name" : "ishimwe aimable",
            "user_name" : "wizwolf",
            "email" : "ishimweaimable@gmail.com",
            "phone" : "+25079688248",
            "password" : "wizwolf250",
            "retype-password" : "wizwolf250",
            "admin" : True},
            follow_redirects=True,
        )
            
    	assert response.status_code == 200
    	assert response.request.path == "auth/login"
    	
    	response = self.client.post("/auth/login", dara={
            "user_name" : "wizwolf",
            "password" : "wizwolf250",
            },
            follow_redirects=True,
        )
            
    	assert response.status_code == 200
    	#: html = response.get_data(as_text=True)
    	#: assert 'Hi, {}!'
    	assert response.request.path == "/home"
    
    def test_register_user_mismatched_passwords(self):
        response = self.client.post("/auth/register", data={
            "name" : "ishimwe aimable",
            "user_name" : "wizwolf",
            "email" : "ishimweaimable@gmail.com",
            "phone" : "+25079688248",
            "password" : "wizwolf250",
            "retype-password" : "wizwolf250",
            "admin" : True},
        )
            
        assert response.status_code == 200
        html = response.get_data(as_text=True)
        assert "password is not valid!" in html
        
    def populate_db(self):
    	user = User(name="ishimwe aimable", user_name="wizwolf", email="ishimweaimable@gmail.com", phone="+250789688248", my_password="wizwolf", admin=True)
    	user.set_password('wizwolf250')
    	db.session.add(user)
    	db.session.commit()
    	
    def login(self):
    	self.client.post("/auth/login",
    	    data={
    	        "user_name" : "wizwolf",
    	        "password" : "wizwolf250",
    	    },
    	)