import datetime
from flask import Blueprint
from flask import url_for, jsonify, redirect, render_template, request, session, abort, flash, Flask
from flask import current_app as app
from flask_login import current_user, login_required
from markupsafe import escape

from shop.models import Cart, Item

from shop.utils.db import db

cart_bp = Blueprint(
    'cart_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

@cart_bp.route("/add", methods=['POST'])
@login_required
def add_to_cart():
	#: add item to cart
	id = request.form.get("item_id")
	item = Item.query.get(id)
	
	quantity = 1
    #quantity = request.form["quantity"]
	current_user.add_to_cart(id, quantity)
		
	flash(f'''{item.name} successfully added to the <a href=cart>cart</a>.<br> <a href={url_for("cart_bp.cart")}>view cart!</a>''','success')
	return jsonify({'success': True}) #: redirect(url_for('home_bp.index'))

@cart_bp.route("/cart")
@login_required
def cart():
	price = 0
	price_ids = []
	items = []
	quantity = []
	for cart in current_user.cart:
		items.append(cart.item)
		quantity.append(cart.quantity)
		price_id_dict = {
			"price": cart.item.price_id,
			"quantity": cart.quantity,
			}
		price_ids.append(price_id_dict)
		price += cart.item.price*cart.quantity
	return render_template('cart.html', items=items, price=price, price_ids=price_ids, quantity=quantity, title="My Cart")

@cart_bp.route("/remove", methods=["POST"])
@login_required
def remove():
	id = request.form.get("item_id")
	quantity = request.form.get("quantity")
	
	current_user.remove_from_cart(id, quantity)
	
	return jsonify({'success': True}) #: redirect(url_for('cart_bp.cart'))

@cart_bp.route("/increase", methods=["POST"])
@login_required
def increase():
    #quantity = 1
    id = request.form.get("item_id")
    quantity = request.form.get("quantity")
    #quantity = request.form["quantity"]
    q = current_user.increase_quantity(id) #: flash(f'''{item.name} successfully added to the <a href=cart>cart</a>.<br> <a href={url_for("cart_bp.cart")}>view cart!</a>''','success')
    return jsonify({'quantity': q}) #: redirect(url_for('cart_bp.cart'))

@cart_bp.route("/decrease", methods=["POST"])
@login_required
def decrease():
    id = request.form.get("item_id")
    quantity = request.form.get("quantity")
    q = current_user.decrease_quantity(id)
    #: flash(f'''{item.name} successfully added to the <a href=cart>cart</a>.<br> <a href={url_for("cart_bp.cart")}>view cart!</a>''','success')
    return jsonify({'quantity': q}) #: redirect(url_for('cart_bp.cart'))


@cart_bp.route("/quantity", methods=["POST"])
@login_required
def quantity():
    id = request.form.get("item_id")
    quantity = request.form.get("quantity")
    current_user.increase_quantity(id, quantity)
    #: flash(f'''{item.name} successfully added to the <a href=cart>cart</a>.<br> <a href={url_for("cart_bp.cart")}>view cart!</a>''','success')
    return jsonify({'success': True}) #: redirect(url_for('cart_bp.cart'))

    
@cart_bp.route("/empty", methods=["POST"])
@login_required
def empty_cart():
    carts = Cart.query.filter_by(uid=current_user.id).all()
    if carts:
        for item in carts:
            db.session.delete(item)
            db.session.commit()
            
    flash("Cart is empty now!", "success")
    return jsonify({'success': True}) #: redirect(url_for("cart_bp.cart"))
