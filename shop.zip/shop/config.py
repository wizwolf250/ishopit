import os
import os.path as op
from datetime import datetime, timedelta



basedir = os.path.abspath(os.path.dirname(__file__))  
database_ = 'sqlite:///' + os.path.join(basedir, 'database')

class Config(object):
    DEBUG = False
    TESTING = False
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
class ProductionConfig(Config):
    #DATABASE_FILE = "hoobe[production].db"
    SQLALCHEMY_DATABASE_URI = database_ + "/database[production].db" # 'sqlite:///' + os.path.join(basedir, '/database/database.db')

    SECRET_KEY_ = 'secrete-1s-a-key-t0-secur1ty!'
    SECRET_KEY = SECRET_KEY_
    JWT_SECRET_KEY = SECRET_KEY_
    JWT_COOKIE_SECURE = False
    JWT_TOKEN_LOCATION = ["cookies"]
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(seconds = 10)
    JWT_COOKIE_CSRF_PROTECT = True
    JWT_ACCESS_COOKIE_NAME = "token"
    JWT_SESSION_COOKIE = False
    JWT_COOKIE_SAMESITE = "Strict"
    JWT_CSRF_IN_COOKIES = True
    JWT_ACCESS_CSRF_COOKIE_NAME = "Tokens"
    JWT_ALGORITHM = "HS256"
    
    FLASK_ADMIN_SWATCH = "default"
    SESSION_TYPE = "filesystem"
    
    DEBUG_WITH_APTANA = True
    
    UPLOADS_FOLDER = "static/uploads/"
    ASSETS_FOLDER = "static/assets/"
    MEDIA_FOLDER = "static/media/"
    STRIPE_SECRET_KEY = "sk_test_51NyRdjFFEF7SlcNlxcc6HYXj67S6LG5T1a1t0iuEqdZlQ8HHmryf4qmpwzFqsb8pvvv4mq3d22Z6Stv5KgDoUGAZ00GZzZk4qd"
    STRIPE_PUBLISHABLE_KEY = "pk_test_51NyRdjFFEF7SlcNlXnJMmUYUKRvZazjexa4NtRvAvwFVRvXbGGkJkIaf4MZrzlBPI826Qn5ptugl0YQ1i7AVvGpw00DRR8Qio9"
    ENDPOINT_SECRET = "gottabekiddingright?"
    
    #: mail
    MAIL_SERVER = "smtp.googlemail.com"
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD")
    
    FLASK_MAIL_SUBJECT_PREFIX = "wizwolf.com" #os.environ.get("FLASK_MAIL_SUBJECT_PREFIX")
    FLASK_MAIL_SENDER = os.environ.get("FLASK_MAIL_SENDER")
    FLASK_ADMIN = os.environ.get("FLASK_ADMIN")
    
    NEWS_API_SECRET = "b504dd7d253e4274ba04fcead9b040ce"
    
    WHOOSH_BASE = "path/to/whoosh/base"
    
    ELASTICSEARCH_URL = "http://elasticsearch:9200"
    
    ARTICLES_PER_PAGE = 20
    
    CKEDITOR_FILE_UPLOADER = "article_bp.upload"
    
    CELERY_BROKER_URL = "redis://localhost:6379/0",
    CELERY_RESULT_BACKEND = "redis://localhost:6379/0",
    TASK_IGNORE_RESULT = True,
    
class DevelopmentConfig(Config):
    DEBUG = True
    #DATABASE_FILE = "hoobe[development].db"
    
    SQLALCHEMY_DATABASE_URI = database_ + "/database[development].db" # 'sqlite:///' + os.path.join(basedir, 'database/database.db')

    SQLALCHEMY_ECHO = False
    SECRET_KEY_ = 'secrete-1s-a-key-t0-secur1ty!'
    SECRET_KEY = SECRET_KEY_
    JWT_SECRET_KEY = SECRET_KEY_
    JWT_COOKIE_SECURE = False
    JWT_TOKEN_LOCATION = ["cookies"]
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(seconds = 10)
    JWT_COOKIE_CSRF_PROTECT = True
    JWT_ACCESS_COOKIE_NAME = "token"
    JWT_SESSION_COOKIE = False
    JWT_COOKIE_SAMESITE = "Strict"
    JWT_CSRF_IN_COOKIES = True
    JWT_ACCESS_CSRF_COOKIE_NAME = "Tokens"
    JWT_ALGORITHM = "HS256"
    
    FLASK_ADMIN_SWATCH = "default"
    SESSION_TYPE = "filesystem"
    
    DEBUG_WITH_APTANA = True
    
    UPLOADS_FOLDER = "static/uploads/"
    ASSETS_FOLDER = "static/assets/"
    MEDIA_FOLDER = "static/media/"
    STRIPE_SECRET_KEY = "sk_test_51NyRdjFFEF7SlcNlxcc6HYXj67S6LG5T1a1t0iuEqdZlQ8HHmryf4qmpwzFqsb8pvvv4mq3d22Z6Stv5KgDoUGAZ00GZzZk4qd"
    STRIPE_PUBLISHABLE_KEY = "pk_test_51NyRdjFFEF7SlcNlXnJMmUYUKRvZazjexa4NtRvAvwFVRvXbGGkJkIaf4MZrzlBPI826Qn5ptugl0YQ1i7AVvGpw00DRR8Qio9"
    ENDPOINT_SECRET = "gottabekiddingright?"
    
    #: mail
    MAIL_SERVER = "smtp.googlemail.com"
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD")
    
    FLASK_MAIL_SUBJECT_PREFIX = "wizwolf.com" #os.environ.get("FLASK_MAIL_SUBJECT_PREFIX")
    FLASK_MAIL_SENDER = os.environ.get("FLASK_MAIL_SENDER")
    FLASK_ADMIN = os.environ.get("FLASK_ADMIN")
    
    NEWS_API_SECRET = "b504dd7d253e4274ba04fcead9b040ce"
    
    WHOOSH_BASE = "path/to/whoosh/base"
    
    ELASTICSEARCH_URL = "http://elasticsearch:9200"
    
    ARTICLES_PER_PAGE = 20 
    
    CKEDITOR_FILE_UPLOADER = "article_bp.upload"
    
    CELERY_BROKER_URL = "redis://localhost:6379/0",
    CELERY_RESULT_BACKEND = "redis://localhost:6379/0",
    TASK_IGNORE_RESULT = True,
    
class TestingConfig(Config):
    TESTING = True
    
    #DATABASE_FILE = "hoobe[testing].db"
    SQLALCHEMY_DATABASE_URI = database_ + "/database[testing].db" # 'sqlite:///' + os.path.join(basedir, 'database/database.db')

    SQLALCHEMY_ECHO = False
    SECRET_KEY_ = 'secrete-1s-a-key-t0-secur1ty!'
    SECRET_KEY = SECRET_KEY_
    JWT_SECRET_KEY = SECRET_KEY_
    JWT_COOKIE_SECURE = False
    JWT_TOKEN_LOCATION = ["cookies"]
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(seconds = 10)
    JWT_COOKIE_CSRF_PROTECT = True
    JWT_ACCESS_COOKIE_NAME = "token"
    JWT_SESSION_COOKIE = False
    JWT_COOKIE_SAMESITE = "Strict"
    JWT_CSRF_IN_COOKIES = True
    JWT_ACCESS_CSRF_COOKIE_NAME = "Tokens"
    JWT_ALGORITHM = "HS256"
    
    FLASK_ADMIN_SWATCH = "default"
    SESSION_TYPE = "filesystem"
    
    DEBUG_WITH_APTANA = True
    
    UPLOADS_FOLDER = "static/uploads/"
    ASSETS_FOLDER = "static/assets/"
    MEDIA_FOLDER = "static/media/"
    STRIPE_SECRET_KEY = "sk_test_51NyRdjFFEF7SlcNlxcc6HYXj67S6LG5T1a1t0iuEqdZlQ8HHmryf4qmpwzFqsb8pvvv4mq3d22Z6Stv5KgDoUGAZ00GZzZk4qd"
    STRIPE_PUBLISHABLE_KEY = "pk_test_51NyRdjFFEF7SlcNlXnJMmUYUKRvZazjexa4NtRvAvwFVRvXbGGkJkIaf4MZrzlBPI826Qn5ptugl0YQ1i7AVvGpw00DRR8Qio9"
    ENDPOINT_SECRET = "gottabekiddingright?"
    
    #: mail
    MAIL_SERVER = "smtp.googlemail.com"
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD")
    
    FLASK_MAIL_SUBJECT_PREFIX = "wizwolf.com" #os.environ.get("FLASK_MAIL_SUBJECT_PREFIX")
    FLASK_MAIL_SENDER = os.environ.get("FLASK_MAIL_SENDER")
    FLASK_ADMIN = os.environ.get("FLASK_ADMIN")
    
    NEWS_API_SECRET = "b504dd7d253e4274ba04fcead9b040ce"
    
    WHOOSH_BASE = "path/to/whoosh/base"
    
    ELASTICSEARCH_URL = "http://elasticsearch:9200"
    
    ARTICLES_PER_PAGE = 20
    
    CKEDITOR_FILE_UPLOADER = "article_bp.upload"
    
    CELERY_BROKER_URL = "redis://localhost:6379/0",
    CELERY_RESULT_BACKEND = "redis://localhost:6379/0",
    TASK_IGNORE_RESULT = True,