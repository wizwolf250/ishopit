import datetime
from flask import Blueprint
from flask import url_for, redirect, render_template, request, session, abort, flash, Flask
from flask import current_app as app

from markupsafe import escape
from shop.models import Item, Cart, Order, Review

from flask_login import current_user, login_required

from shop.forms import AddReviewForm
from shop.utils.db import db


review_bp = Blueprint(
    'review_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

@review_bp.route('/item/<int:id>/reviews')
@login_required
def reviews(id):
	item = Item.query.filter_by(id=id).first()
	reviews = item.reviews
	return render_template('reviews.html', title="Reviews", reviews=reviews, item=item)

@review_bp.route("/item/<int:id>/reviews/add", methods=["GET", "POST"])
@login_required
def add(id):
    item = Item.query.filter_by(id=id).first()
    form = AddReviewForm()
    
    if form.validate_on_submit():
        comment = form.comment.data
        rating = form.rating.data
        
        review = Review(
            itemid=item.id,
            uid=current_user.id,
            comment=comment,
            rating=rating,
        )
        
        db.session.add(review)
        db.session.commit()
        
        return redirect(url_for("review_bp.reviews", id=item.id))
        
    return render_template("add_review.html", item=item, form=form, title="Write a Review")
        