# flask wtf 
from flask_wtf import FlaskForm
# request
from flask import request
# wtf forms
from wtforms import form, fields, EmailField, TextAreaField, StringField, PasswordField, BooleanField, DecimalField, IntegerField, RadioField, FileField, SelectField, SubmitField
from wtforms.fields import SearchField
from wtforms.widgets import TextArea
from wtforms.validators import DataRequired, Email, Length, EqualTo, Regexp

# werkzeug
from werkzeug.security import generate_password_hash, check_password_hash
import werkzeug
from werkzeug.utils import secure_filename


class FeaturesForm(FlaskForm):
    social = BooleanField("Social")
    chat = BooleanField("Chat")    
    music = BooleanField("Music")
    blog = BooleanField("Blog")    
    portfolio = BooleanField("Portfolio")
    store = BooleanField("Store")    
    
    submit = SubmitField("Save changes")


class LoginForm(FlaskForm):
	email = StringField("Email", validators=[DataRequired()], render_kw={'placeholder': 'Username or email'})
	password = PasswordField("Password", validators=[DataRequired()], render_kw={'placeholder': 'Password'})
	submit = SubmitField("Login")

class RegisterForm(FlaskForm):
	name = StringField("Name:", validators=[DataRequired(), Length(max=50)])
	phone = StringField("Phone No:", validators=[DataRequired(), Length(max=30)])
	email = StringField("Email:", validators=[DataRequired(), Email()])
	password = PasswordField("Password:", validators=[DataRequired(), Regexp("^[a-zA-Z0-9_\-&$@#!%^*+.]{8,30}$", message='Password must be 8 characters long and should contain letters, numbers and symbols.')])
	confirm = PasswordField("Confirm Password:",validators=[EqualTo('password', message='Passwords must match')])
	submit = SubmitField("Register")


class EmptyForm(FlaskForm):
    submit = SubmitField()


class ProfileUploadForm(FlaskForm):
    file = FileField("File")
    submit = SubmitField("Save profile")


class ProfileInfoForm(FlaskForm):
    first_name = StringField("Firstname")
    middle_name = StringField("Middlename")
    last_name = StringField("Lastname")
    submit = SubmitField("Save info")
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
class UserRoleForm(FlaskForm):
    user = SelectField("User")
    roles = SelectField("Role")
    submit = SubmitField("Save change")


class SubscribeForm(FlaskForm):
    email = EmailField("Email")   
    submit = SubmitField("Subscribe")  

class AddReviewForm(FlaskForm):
     rating = IntegerField("Rating")
     comment = StringField("Comment")
     submit = SubmitField("Submit a Review")
     
class SearchForm(FlaskForm):
    q = SearchField(
        "Search",
        id="search",
        validators=[DataRequired()],
        render_kw={'placeholder': 'Search...'})

    def __init__(self, *args, **kwargs):
        if 'formdata' not in kwargs:
            kwargs['formdata'] = request.args
            
        if 'meta' not in kwargs:
            kwargs['meta'] = {'csrf': False}
        super(SearchForm, self).__init__(*args, **kwargs) 
    
                                                                                                                                  