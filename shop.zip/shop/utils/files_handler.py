from flask import current_app as app

def get_file(path, filename):
    try:
        path = app.config["UPLOADS_FOLDER"] + path + "/"
        picture = path + filename #session["profile-picture"]
        return "/" + picture
        
    except Exception as e:
        pass                  
    
def find_file(filename):
    try:
        pass
    except Exception as e:
        pass
    
def save_file(path, filename):
    pass
    