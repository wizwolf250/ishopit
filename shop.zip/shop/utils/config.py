import os
import os.path as op
from datetime import datetime, timedelta



basedir = os.path.abspath(os.path.dirname("app.py"))  
database_ = 'sqlite:///' + os.path.join(basedir, 'database')

class Config(object):
    DEBUG = False
    TESTING = False
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
class ProductionConfig(Config):
    #DATABASE_FILE = "hoobe[production].db"
    SQLALCHEMY_DATABASE_URI = database_ + "/database[production].db" # 'sqlite:///' + os.path.join(basedir, '/database/database.db')

    SECRET_KEY_ = 'secrete-1s-a-key-t0-secur1ty!'
    SECRET_KEY = SECRET_KEY_
    JWT_SECRET_KEY = SECRET_KEY_
    JWT_COOKIE_SECURE = False
    JWT_TOKEN_LOCATION = ["cookies"]
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(seconds = 10)
    JWT_COOKIE_CSRF_PROTECT = True
    JWT_ACCESS_COOKIE_NAME = "token"
    JWT_SESSION_COOKIE = False
    JWT_COOKIE_SAMESITE = "Strict"
    JWT_CSRF_IN_COOKIES = True
    JWT_ACCESS_CSRF_COOKIE_NAME = "Tokens"
    JWT_ALGORITHM = "HS256"
    
    FLASK_ADMIN_SWATCH = "default"
    SESSION_TYPE = "filesystem"
    
    DEBUG_WITH_APTANA = True
    
    UPLOADS_FOLDER = "static/uploads/"
    
    
class DevelopmentConfig(Config):
    DEBUG = True
    #DATABASE_FILE = "hoobe[development].db"
    
    SQLALCHEMY_DATABASE_URI = database_ + "/database[development].db" # 'sqlite:///' + os.path.join(basedir, 'database/database.db')

    SQLALCHEMY_ECHO = False
    SECRET_KEY_ = 'secrete-1s-a-key-t0-secur1ty!'
    SECRET_KEY = SECRET_KEY_
    JWT_SECRET_KEY = SECRET_KEY_
    JWT_COOKIE_SECURE = False
    JWT_TOKEN_LOCATION = ["cookies"]
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(seconds = 10)
    JWT_COOKIE_CSRF_PROTECT = True
    JWT_ACCESS_COOKIE_NAME = "token"
    JWT_SESSION_COOKIE = False
    JWT_COOKIE_SAMESITE = "Strict"
    JWT_CSRF_IN_COOKIES = True
    JWT_ACCESS_CSRF_COOKIE_NAME = "Tokens"
    JWT_ALGORITHM = "HS256"
    
    FLASK_ADMIN_SWATCH = "default"
    SESSION_TYPE = "filesystem"
    
    DEBUG_WITH_APTANA = True
    
    UPLOADS_FOLDER = "static/uploads/"
    
class TestingConfig(Config):
    TESTING = True
    
    #DATABASE_FILE = "hoobe[testing].db"
    SQLALCHEMY_DATABASE_URI = database_ + "/database[testing].db" # 'sqlite:///' + os.path.join(basedir, 'database/database.db')

    SQLALCHEMY_ECHO = False
    SECRET_KEY_ = 'secrete-1s-a-key-t0-secur1ty!'
    SECRET_KEY = SECRET_KEY_
    JWT_SECRET_KEY = SECRET_KEY_
    JWT_COOKIE_SECURE = False
    JWT_TOKEN_LOCATION = ["cookies"]
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(seconds = 10)
    JWT_COOKIE_CSRF_PROTECT = True
    JWT_ACCESS_COOKIE_NAME = "token"
    JWT_SESSION_COOKIE = False
    JWT_COOKIE_SAMESITE = "Strict"
    JWT_CSRF_IN_COOKIES = True
    JWT_ACCESS_CSRF_COOKIE_NAME = "Tokens"
    JWT_ALGORITHM = "HS256"
    
    FLASK_ADMIN_SWATCH = "default"
    SESSION_TYPE = "filesystem"
    
    DEBUG_WITH_APTANA = True
    
    UPLOADS_FOLDER = "static/uploads/"
    

