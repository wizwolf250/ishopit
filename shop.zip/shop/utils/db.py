from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy() #SQLAlchemy instance
