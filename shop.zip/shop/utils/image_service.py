import os
from PIL import Image
from flask import current_app as app

def resize_and_save_image(image_path : str, sizes=[250, 500, 1000]):
    """
    Resize image and save it in different sizes
    
    Args:
        image_path : str path to the original image
        sizes : list of sizes
        return None
    """
    try:
        
        with Image.open(image_path) as image:
            for size in sizes:
                #: resize image
                resized_image = image.resize((size, size), Image.ANTIALIAS)
                #: resized image filename
                resized_filename = f"{os.path.splitext(image_path)[0]}_{size}{os.path.splitext(image_path)[1]}"
                #: resized image path
                resized_path = os.path.join(app.config['RESIZED_IMAGES_FOLDER'], resized_filename)
                #: resized image save
                resized_image.save(resized_path)
                
    except Exception as e:
        print(str(e))