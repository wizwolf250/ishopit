from datetime import datetime
from dateutil import tz

utc = tz.tzutc()
local = tz.tzlocal()

utc_now = datetime.utcnow()

utc_now = utc_now.replace(tzinfo=utc)

local_now = utc_now.astimezone(local)

print(utc_now)
print(local_now)