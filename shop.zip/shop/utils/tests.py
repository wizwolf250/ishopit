from flask_wtf import FlaskForm
from wtforms import SelectMultipleField

class ProductForm(FlaskForm):
    colors = SelectMultipleField('Colors')

    def __init__(self, *args, **kwargs):
        super(ProductForm, self).__init__(*args, **kwargs)
        
        # Fetch colors from the database
        colors = Color.query.all()
        
        # Populate choices for the SelectMultipleField
        self.colors.choices = [(color.id, color.name) for color in colors]
