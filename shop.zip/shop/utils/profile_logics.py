from flask import session
from flask_login import current_user
from flask import current_app as app

def is_default_profile_picture(user=None):
    try:
        if user is None:
            #: user id
            id = session["id"]
            
            if session["profile-picture"] == "blank_avatar.png":
                path = app.config["UPLOADS_FOLDER"] + "profile/default/"
                profile_picture = path + session["profile-picture"]
                return "/" + profile_picture  
                
            else:
                path = app.config["MEDIA_FOLDER"] + f"users/{id}/avatars/"
                profile_picture = path + session["profile-picture"]
                return "/" + profile_picture
    
        if user:
            #: user id
            id = user.id
            
            if user.avatar == "blank_avatar.png":
                path = app.config["UPLOADS_FOLDER"] + "profile/default/"
                profile_picture = path + user.avatar
                return "/" + profile_picture  
                
            else:
                path = app.config["MEDIA_FOLDER"] + f"users/{id}/avatars/"
                profile_picture = path + user.avatar #"profile-picture"]
                return "/" + profile_picture
            
    except Exception as e:
        return str(e)
        
