// review.js
jQquery(function($){
	// function to animate a star
	function animateStarIcon(){
		$('.checked span').animate({fontSize: '46px'}, 100).animate({fontSize: '28px'}, 100);	
	}
	
	// function add a star
	$(".checked span").click(function(e){
		// codes to add star to review
        e.preventDefault();
        
        var item_id = $(this).data('item-id');
        //var quantity = $(this).siblings('input[name="quantity"]').val();
    
        $.ajax({
       	 url: `/item/${item_id}/reviews/add`,
            method: 'POST',
            data: {item_id: item_id},
        	success: function(response) {
            // Update star color
            animateStarIcon();
            //: alert('Item added to cart successfully!');
        	},
            error: function(xhr, status, error) {
            	alert('An error occurred while adding the star to review!');
            }
   	 });
	});
});