// animations wizwolf
/*
const elements = document.querySelectorAll("animated");

const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting){
            entry.target.classList.add('show');
            // entry.target.classList.remove('hide');
        }else{
            // entry.target.classList.add('hide');
            entry.target.classList.remove('show');
        }
    });
});

elements.forEach((element) => observer.observe(element));
*/
/*
var direction = Math.floor(Math.random() * 300) + -300;

window.addEventListener('scroll', () => {
    const scrollTop = window.scrollY;
    const elements = document.querySelectorAll('.animated');

    elements.forEach((element) => {
        // element
        const elementTop = element.offsetTop; // Get the top position of the element
        const elementBottom = elementTop + element.offsetHeight; // Calculate the bottom position

        // Check if the element is within the viewport (taking into account a buffer for smooth transitions)
        if (scrollTop + window.innerHeight - 50 > elementTop && scrollTop < elementBottom - 50) {
            element.classList.remove('hide'); // Remove the animation class if it's not in view
            element.classList.add('show'); // Add the animation class to trigger the animation
        
        } else {
            element.classList.remove('show'); // Remove the animation class if it's not in view
            element.classList.add('hide'); // Add the animation class to trigger the animation
            element.style.setProperty('--animation-direction', direction + 'px');
        }
    });
});
*/

jQuery(function($){
    // function animate ball
    function animateBall() {
        $(".ball").animate({left: "1", width: "100px", height: "85px"}, 5000).animate({left: "0", width: "85px", height: "100px"}, 5000).animate({left: "1", width: "100px", height: "100px"}, 5000);
    }
    
    $(document).click(function(){
        animateBall();
    });
});
