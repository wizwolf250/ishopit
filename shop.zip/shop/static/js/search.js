// Function to fetch search results via AJAX

function search(query) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/search?query=' + query, true);

    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 400) {
            var data = JSON.parse(xhr.responseText);
            displaySearchResults(data);
        } else {
            console.error('Request failed: ' + xhr.status);
        }
    };

    xhr.onerror = function() {
        console.error('Request failed');
    };

    xhr.send();
}

// Function to display search results
function displaySearchResults(results) {
    var container = document.getElementById('search-results-container');
    container.innerHTML = ''; // Clear previous results

    if (results.length > 0) {
        var heading = document.createElement('h3');
        heading.textContent = 'Search results:';
        container.appendChild(heading);

        var list = document.createElement('ul');
        results.forEach(function(result) {
            var listItem = document.createElement('li');
            listItem.textContent = result;
            list.appendChild(listItem);
        });
        container.appendChild(list);
    } else {
        var noResults = document.createElement('h6');
        noResults.textContent = 'No results found.';
        container.appendChild(noResults);
    }
}

// Event listener for form submission
document.getElementById('search-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission
    var query = document.getElementById('search-form').querySelector('input').value;
    search(query); // Call the search function with the query
});

// Function to display search results
function displaySearchResults(results) {
    var container = document.getElementById('search-results-container');
    container.innerHTML = ''; // Clear previous results

    if (results.length > 0) {
        var heading = document.createElement('h3');
        heading.textContent = 'Search results:';
        container.appendChild(heading);

        results.forEach(function(item) {
            // Include search_item.html template
            var searchItemTemplate = `
                <a class="link" href="{{ url_for('product_bp.item', id=${item.id}) }}">
                    <div class="card">
                        <div class="card-body shadow">
                            <div class="row align-items-center d-flex g-4">
                                <div class="col-auto">
                                    <img class="rounded" src="${item.image}" style="width: 50px; height: 50px;"/>
                                </div>
                                <div class="col-8">
                                    <b>${item.name}</b>
                                    <br>
                                    <span class="text-secondary">$${item.price}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>`;
                
            // Create a temporary container element to hold the HTML content
            var tempContainer = document.createElement('div');
            tempContainer.innerHTML = searchItemTemplate;
            // Append the first child of the temp container to the main container
            container.appendChild(tempContainer.firstChild);
        });
    } else {
        var noResults = document.createElement('h6');
        noResults.textContent = 'No results found.';
        container.appendChild(noResults);
    }
}


function searchData(query) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/search?q=' + query, true);

    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 400) {
            var data = JSON.parse(xhr.responseText);
            updateSearchResults(data.items);
        } else {
            console.error('Request failed: ' + xhr.status);
        }
    };

    xhr.onerror = function() {
        console.error('Request failed');
    };

    xhr.send();
}

function updateSearchResults(items) {
    // Update search results container with received items
}
