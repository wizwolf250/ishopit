// Navbar
const header = document.querySelector(".navbar");
//const mySpace = document.guerySelector(".space");
const brandText = document.querySelector(".navbarBrandText");
//alert("Hi");
const navbarBtnToggler = document.querySelector(".navbar-toggler");
const navbarIcon = document.querySelector(".navbar-toggler-icon");
const navRightIcon = document.querySelector(".nav-right-link");

// bottom navigation
// const bottomNavItems = document.querySelector(".bottom-nav-item"); //: document.querySelector(".bottom-nav-item");

// search input
const searchInput = document.getElementById("search");
// skeleton
const skeletonItems = document.querySelector(".skeleton");

window.onscroll = function(){
    var top = window.scrollY;
    
    if (top >= 20){
        header.classList.add('navbarDark');
        brandText.style.setProperty("color", "var(--dark-text);", "");
        navbarBtnToggler.style.setProperty("background", "var(--background-color);", "");
        navbarIcon.style.setProperty("color", "var(--light-text);", "");
        //navRightIcon.style.setProperty("color", "black", "");
    }
    
    else {
        header.classList.remove('navbarDark');
        brandText.style.setProperty("color", "var(--light-text);", "");
        navbarBtnToggler.style.setProperty("background", "var(--background-color);", "");
        navbarIcon.style.setProperty("color", "var(--dark-text);", "");
        //navRightIcon.style.setProperty("color", "white", "");
    }
}
/*
const myModal = document.querySelector(".modal");

myModal.addEventListener('show.bs.modal', () => {
    
});
*/

searchInput.addEventListener("input", function(){
// check if searchInput.value if is in items
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/search? query=' + query, true);
    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 400){
            var data = JSON.parse(xhr.responseText);
            updateSearchField(data); // update search field
            
        }else{
            console.error("error", xhr.status);
        }
    };
    
    xhr.onerror = function() {
        console.error('Request failed');
    };
    xhr.send();
});

function updateSearchField(data){
    var searchField = document.getElementById('search');
    searchField.innerHTML = '';
    data.forEach(function(item){
        alert(data);
    });
}

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
        switchColorScheme();
});

function switchColorScheme() {
    document.querySelector('html')!.dataset.bsTheme = window.matchMedia('(prefers-color-scheme: dark)').matches
        ? "dark"
        : "light";
}

switchColorScheme();