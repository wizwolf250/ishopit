// cart.js 
jQuery(function($){
    // Function to animate the cart icon
    function animateCartIcon() {
        $('#cart-icon i').animate({fontSize: '46px'}, 100).animate({fontSize: '28px'}, 100);
    }
    
    $('.add-to-cart_').click(function(e){
        // codes to add item to cart;
        e.preventDefault();
        
        var item_id = $(this).data('item-id');
        var quantity = $(this).siblings('input[name="quantity"]').val();
    
        $.ajax({
            url: '/add',
            method: 'POST',
            data: {item_id: item_id, quantity: quantity},
            success: function(response) {
                // Update cart content or display success message
                animateCartIcon();
                //: alert('Item added to cart successfully!');
            },
            error: function(xhr, status, error) {
                alert('An error occurred while adding the item to cart!');
            }
        });
    });
    
    $('.remove-to-cart_').click(function(e){
        // codes to remove item from cart;
        e.preventDefault();
        
        var item_id = $(this).data('item-id');
        var quantity = $(this).siblings('input[name="quantity"]').val();
    
        $.ajax({
            url: '/remove',
            method: 'POST',
            data: {item_id: item_id, quantity: quantity},
            success: function(response){
                alert("Removed successfully!");
            },
            error: function(xhr, status, error) {
                alert('An error occurred while removing the item to cart!');
            }
        }); 
    });
    
    
    $('.increase').click(function(e){
        // increase quantity of item in cart;
        e.preventDefault();
        
        var item_id = $(this).data('item-id');
        var quantity = $(this).siblings('input[name="quantity"]').val();
        var quantity_input = $(this).siblings('input[name="quantity"]');
    
        $.ajax({
            url: '/increase',
            method: 'POST',
            data: {item_id: item_id, quantity: quantity},
            success: function(response) {
                // Update cart content or display success message
                quantity_input.val(response.quantity);
                alert('Increased quantity of item successfully!');
            },
            error: function(xhr, status, error) {
                alert('An error occurred while increasing the item quantity!');
            }
        });
    });
    
    $('.decrease').click(function(e){
        // decrease quantity of item in cart;
        e.preventDefault();
        
        var item_id = $(this).data('item-id');
        var quantity = $(this).siblings('input[name="quantity"]').val();
        var quantity_input = $(this).siblings('input[name="quantity"]');
    
        $.ajax({
            url: '/decrease',
            method: 'POST',
            data: {item_id: item_id, quantity: quantity},
            success: function(response) {
                // Update cart content or display success message
                quantity_input.val(response.quantity);
                alert('Decreased quantity of item successfully!');
            },
            error: function(xhr, status, error) {
                alert('An error occurred while decreasing the item quantity!');
            }
        });
    });
    
    /*
    $('.add-star').click(function(this){
        // add a star on item;
    });
    
    $('.remove-star').click(function(this){
        // remove a star on item;
    });
    
    $('.add-comment').click(function(this){
        // add a comment on item;
    });
    */
});
