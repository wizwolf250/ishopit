const chrt = document.getElementById("myChart").getContext('2d');
const myChart = new Chart(
    chrt, 
    {
        type : "bar",
        data : {
            labels : ["Html5", "Bootstrap5", "Css3", "JS", "C", "Python"],
            datasets : [{
                label : "Online tutorials",
                data : [25, 43, 58, 55, 12, 87],
            }],
        },
        options : {
            responsive : true,
        },
    }
);