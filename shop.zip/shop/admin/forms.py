from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SelectField, SubmitField, FloatField, FileField, MultipleFileField, SelectMultipleField
from wtforms.validators import DataRequired, Length
from shop.models import Category, Color

class AddItemForm(FlaskForm):
    name = StringField("Name:", validators=[DataRequired(), Length(max=50)])
    details = StringField("Details:", validators=[DataRequired()])
    price = FloatField("Price:", validators=[DataRequired()])
    #discount = FloatField("Discount:")
    category = SelectField("Category:", validators=[DataRequired()])
    price_id = StringField("Stripe id:", validators=[DataRequired()])
    colors = SelectMultipleField("Colors:", validators=[DataRequired()])
    quantity = IntegerField("Quantity:", validators=[DataRequired()])
    image = FileField("Image:", validators=[DataRequired()])
    images = MultipleFileField("Images:", render_kw={'multiple' : True})
    submit = SubmitField("Add")
   
    def __init__(self, *args, **kwargs):
        super(AddItemForm, self).__init__(*args, **kwargs)
        categories = Category.query.all()
        colors = Color.query.all()
        self.category.choices = [(category.id, category.name) for category in categories]
        self.colors.choices = [(color.id, color.name) for color in colors]
        
class OrderEditForm(FlaskForm):
    status = StringField("Status:", validators=[DataRequired()])
    submit = SubmitField("Update")