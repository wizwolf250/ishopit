import os
from flask import Blueprint, render_template, url_for, flash
from flask import current_app as app
from werkzeug.utils import redirect
from shop.models import User, Order, Item, Category, Inventory, Color, Image, db
from shop.admin.forms import AddItemForm, OrderEditForm
from shop.funcs import admin_only


admin = Blueprint("admin", __name__, url_prefix="/admin", static_folder="static", template_folder="templates")

@admin.route('/')
@admin_only
def dashboard():
    orders = Order.query.all()
    users = User.query.all()
    
    return render_template("admin/home.html", users=users, orders=orders)

@admin.route('/items')
@admin_only
def items():
    items = Item.query.all()
    return render_template("admin/items.html", items=items)

@admin.route('/users')
@admin_only
def users():
    users = User.query.all()
    return render_template("admin/users.html", users=users)

@admin.route('/admins')  
@admin_only
def admins():
	pass
	  
@admin.route('/add', methods=['POST', 'GET'])
@admin_only
def add():
    
    error = None
    
    form = AddItemForm()

    if form.validate_on_submit():
        name = form.name.data
        price = form.price.data
        category = form.category.data
        quantity = form.quantity.data
        #discount = form.discount.data
        details = form.details.data
        images = form.images.data
        colors = form.colors.data
        image = form.image.data
        price_id = form.price_id.data
        
        if not name:
            error = "Name can't be empty"
            
        if not details:
            error = "Details can't be empty"
            
        if not price:
            error = "Price can't be empty"
            
        if not category:
            error = "Category not found!"
            
        if not quantity:
            error = "Quantity can't be empty, quantity is like stock quantity!"
        
        if not price_id:
            error = "Stripe id is required"
            
        if not colors:
            error = "Colors for this item is needed, choose the available colors!"
        
        if not image:
            error = "Choose image for this item"
        
        if not images:
            error = "You need to select more images for item details!"
        
        if error is None:
            image.save(os.path.join(app.config["UPLOADS_FOLDER"], image.filename))
            image = url_for('static', filename=f'uploads/{image.filename}')
        
            category = Category.query.filter_by(id=category).first()

            inventory = Inventory(quantity=quantity)
            db.session.add(inventory)
            db.session.commit()
        
            selected_colors = Color.query.filter(Color.name.in_(colors)).all()
            
            item = Item(name=name, price=price, category_id=category.id, inventory_id=inventory.id, details=details, image=image, price_id=price_id)
            
            if selected_colors:
                #: item colors
                for color in selected_colors:
                    item.colors.append(color)
                    db.session.commit()
                
            if images:
                #: item images 
                for img in images:
                    image = Image(itemid=item.id, image=img.filename)
                    item.images.append(image)
                    db.session.commit()
                    img.save(os.path.join(app.config["UPLOADS_FOLDER"], img.filename))
                    img = url_for('static', filename=f'uploads/{img.filename}')
            
            db.session.add(item)
            db.session.commit()
            
            flash(f'{name} added successfully!','success')
            return redirect(url_for('admin.items'))
        
        flash(error, "error")
        return redirect(url_for('admin.add'))
        
    return render_template("admin/add.html", form=form)

@admin.route('/edit/<string:type>/<int:id>', methods=['POST', 'GET'])
@admin_only
def edit(type, id):
    if type == "item":
        item = Item.query.get(id)
        form = AddItemForm(
            name = item.name,
            price = item.price,
            category = item.category,
            details = item.details,
            image = item.image,
            price_id = item.price_id,
        )
        if form.validate_on_submit():
            item.name = form.name.data
            item.price = form.price.data
            item.category = form.category.data
            item.details = form.details.data
            item.price_id = form.price_id.data
            form.image.data.save(os.path.join(app.config["UPLOADS_FOLDER"], form.image.data.filename))
            item.image = url_for('static', filename=f'uploads/{form.image.data.filename}')
            db.session.commit()
            return redirect(url_for('admin.items'))
            
    elif type == "order":
        order = Order.query.get(id)
        form = OrderEditForm(status = order.status)
        if form.validate_on_submit():
            order.status = form.status.data
            db.session.commit()
            return redirect(url_for('admin.dashboard'))
    return render_template('admin/add.html', form=form)

@admin.route('/delete/<int:id>')
@admin_only
def delete(id):
    to_delete = Item.query.get(id)
    db.session.delete(to_delete)
    db.session.commit()
    flash(f'{to_delete.name} deleted successfully', 'error')
    return redirect(url_for('admin.items'))
    
@admin.route('/features')  
@admin_only
def features():
	pass
	
@admin.route('/ecommerce')  
@admin_only
def ecommerce():
	pass
	
@admin.route('/calendary')  
@admin_only
def calendary():
	pass
	
@admin.route('/mail')  
@admin_only
def mail():
	pass
	
@admin.route('/chat')  
@admin_only
def chat():
	pass
	
@admin.route('/contacts')  
@admin_only
def contacts():
	pass
	
@admin.route('/todo')  
@admin_only
def todo():
	pass
	
@admin.route('/file_manager')  
@admin_only
def file_manager():
	pass

@admin.route('/notifications')  
@admin_only
def notifications():
	pass

@admin.route('/search')  
@admin_only
def search():
	pass
	
@admin.route('/theme')  
@admin_only
def theme():
	pass
					
@admin.route('/settings')  
@admin_only
def settings():
	pass