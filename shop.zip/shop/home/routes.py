import datetime
import json
from flask import Blueprint
from flask import url_for, redirect, render_template, request, session, abort, flash, jsonify, g, Flask
from flask import current_app as app
from flask_login import login_required, current_user
from markupsafe import escape
from shop.forms import SubscribeForm, EmptyForm, SearchForm
# cache
#: markup safe
from markupsafe import escape
#profile logics
from shop.utils.profile_logics import is_default_profile_picture
# db
from shop.utils.db import db

from shop.models import User, Cart, Item, Order, Ordered_item

from shop.extensions import cache

home_bp = Blueprint(
    'home_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

@app.before_request
def before_request():
    g.search_form = SearchForm()
    g.subForm = SubscribeForm()

@app.context_processor
def inject_year():
    current_year = datetime.datetime.now().year
    return dict(year=current_year)
    

@app.context_processor
def inject_profile_picture():
    def profile_picture(user=None):
        try:
            if user is None:
                id = current_user.id
                if session["profile-picture"] == "blank_avatar.png":
                    path = app.config["ASSETS_FOLDER"] + "default/"
                    profile_picture = path + session["profile-picture"]
                    return "/" + profile_picture  
                
                else:
                    path = app.config["MEDIA_FOLDER"] + f"users/{id}/avatars/"
                    profile_picture = path + session["profile-picture"]
                    return "/" + profile_picture
    
            if user:
                id = user.id
                
                if user.avatar == "blank_avatar.png":
                    path = app.config["ASSETS_FOLDER"] + "default/"
                    profile_picture = path + user.avatar
                    return "/" + profile_picture  
                
                else:
                    path = app.config["MEDIA_FOLDER"] + f"users/{id}/avatars/"
                    profile_picture = path + user.avatar #"profile-picture"]
                    return "/" + profile_picture
            
        except Exception as e:
            return str(e) 
        
    return dict(profile_picture=profile_picture)

@app.context_processor
def inject_file_handler():
    def get_file(article, many=False):
        try:
            id = article.id
            
            _path = app.config["MEDIA_FOLDER"] + f"articles/files/"
            if many is True:
                images = []
                for file in article.article_files:
                    image = _path + file #session["profile-picture"]
            
                    images.append("/" + image)
                
                return images
            
            else:
                for file in article.article_files:
                    image = _path + article.article_files[0] #session["profile-picture"]
            
                    return "/" + image                  
        
        except Exception as e:
            return str(e) 
            
    return dict(get_file=get_file)            
    
@home_bp.route("/", methods=["GET", "POST"])
@home_bp.route("/index", methods=["GET", "POST"])
@home_bp.route("/home", methods=["GET", "POST"])
@cache.cached(timeout=30)
def index():
    try:
        # subscribe form
        subForm = SubscribeForm()
        #: products
        items = Item.query.all()
        item = Item.query.first()
        collection = Item.query.all()
        
        return render_template(
            "index.html",
            title='Home - iShop',
            template="home-template",
            subForm=subForm,
            items=items,
            item=item,
            collection=collection,
        )
        
    except Exception as e:
        return jsonify({"error" : str(e)})  #: redirect(url_for("home_bp.index"))
    

@home_bp.route('/search', methods=["GET",])
@cache.cached(timeout=1)
def search():
    #: search
    
    if not g.search_form.validate():
        return redirect(url_for('home_bp.search'))
    
    query = request.args["q"]
    search = "%{}%".format(query)
    items = Item.query.filter(Item.name.like(search)).all()
    
    return render_template(
        'index.html',
        title='Search',
        search=True,
        query=query,
        items=items,
        #: subForm=subForm,
    )
  	  
@home_bp.get("/theme")
@cache.cached(timeout=1)
def toggle_theme():
    try:
        # current theme
        current_theme = session.get("theme")
        
        if current_theme == "light":
            session["theme"] = "dark"
        
        if current_theme == "dark":
            session["theme"] = "light"
            
        else:
            session["theme"] = "light"
        
        return redirect(request.args.get("current_page"))
    
    except Exception as e:
        return redirect(request.args.get("current_page"))

             
@app.errorhandler(404)
def not_found_error(error):
    return render_template("errors/404.html"), 404
    
@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template("errors/500.html"), 500

        


    