import os
from threading import Thread
import json
import datetime
from flask import Blueprint
from flask import url_for, redirect, render_template, request, session, abort, flash, Flask
from flask import current_app as app
from flask_login import user_loaded_from_request, login_user, login_required, LoginManager, current_user, UserMixin, logout_user
from shop.models import User, Item, Cart, Ordered_item, Order
from markupsafe import escape

from shop.forms import SubscribeForm, EmptyForm
from shop.utils.db import db
#profile logics
from shop.utils.profile_logics import is_default_profile_picture
#from ubu.utils.chat_tools import generate_unique_code

import werkzeug
from werkzeug.utils import secure_filename

from markupsafe import escape

from celery import shared_task

ALLOWED_EXTENSIONS = {"jpeg", "png", "jpg", "JPG", "JPEG", "PNG"}

def allowed_file(filename):
    return "." in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


account_bp = Blueprint(
    'account_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

@account_bp.context_processor
def inject_year():
    current_year = datetime.datetime.now().year
    return dict(year=current_year)

# ... other routes and views

@account_bp.route("/profile/<user_name>/", methods=["GET", "POST"])
@login_required
def profile(user_name):
    # user
    user = User.query.filter_by(user_name=user_name).first_or_404()
    #articles = Article.query.filter_by(author=user).all()
    # subscribe form       
    subForm = SubscribeForm()
    deleteForm = EmptyForm()
    
    return render_template(
        "profile.html",
        title='Profile',
        subtitle="Profile",
        template="profile-template",
        user=user,
        subForm=subForm,
        deleteForm=deleteForm,
    )
    
@account_bp.route("/profile/upload-profile/", methods=["GET", "POST"])  
@login_required
def upload_profile():
    error = None

    if request.method == "POST":
        avatar = request.files["file"]
            
        if avatar is None:
            error = "Profile picture is not uploaded!"
                
        if avatar is not None and allowed_file(avatar.filename):
            result = upload(avatar)
            flash(result["msg"])
            return redirect(url_for("account_bp.profile", user_name=current_user.user_name))
                
        flash(error)
        
        return redirect(url_for("account_bp.upload_profile"))
                
    return render_template("upload_profile.html", title="Upload Profile")   

#: @shared_task(task_ignore_result=False)
def upload(avatar):
    id = current_user.id
    filename = secure_filename(avatar.filename)
    path = os.path.join(app.config["MEDIA_FOLDER"], f"users/{id}/avatars/")
            
    #: check if path exists
    if not os.path.exists(path):
        os.makedirs(path)
    #: avatar
    avatar.save(os.path.join(path, filename))
                
    user = User.query.filter_by(id=current_user.id).first_or_404()
    user.avatar = filename
    db.session.add(user)
    
    db.session.commit()
                
    session["profile-picture"] = user.avatar
    
    return {"msg" : "Profile picture uploaded successfully!"}
    
@account_bp.route("/account/settings/", methods=["GET", "POST"])
@login_required
def account_settings():
    return render_template("account_settings.html", title="Account Settings")

@account_bp.route("/profile/edit/", methods=["GET", "POST"])
@login_required
def edit_profile():
    return render_template("edit_profile.html", title="Edit Profile")
    
class FileJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        try:
            return obj.isoformat()
            
        except AttributeError:
            return super(FileJSONEncoder, self).default(obj)