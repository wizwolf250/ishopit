import datetime
from flask import Blueprint
from flask import url_for, redirect, render_template, request, session, abort, flash, Flask
from flask import current_app as app

from markupsafe import escape
#from shop.models import Item, Cart, Order, Review

from flask_login import current_user, login_required

from shop.forms import SubscribeForm


cookies_bp = Blueprint(
    'cookies_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

@cookies_bp.route('/cookies')
def cookies():
    subForm = SubscribeForm()
    
    return render_template('cookies.html', title="Cookies Policy", subForm=subForm)
