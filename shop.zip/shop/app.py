#: app.py
import os
import os.path as op
from datetime import datetime, timedelta
from flask import url_for, redirect, render_template, request, session, abort, flash, Flask

from flask_dance.contrib.github import github

# celery
from celery import Celery, Task

# models
from shop.models import User, Role, Item, Cart, Order, Ordered_item, Contact, Subscribe, Setting, Category, Color

# database
from shop.utils.db import db
# config
from shop.config import DevelopmentConfig, ProductionConfig, TestingConfig

# migrate
from flask_migrate import Migrate

# search 
from elasticsearch import Elasticsearch

# assets
from flask_assets import Environment
from shop.assets import compile_static_assets

# moment
from shop.extensions import moment, mail, cache, ckeditor, celery_init_app #news_api
    
from werkzeug.security import generate_password_hash, check_password_hash   
#: bootstrap
from flask_bootstrap import Bootstrap

                    
def create_app(config_name = None): #: create app
    #: create app
    app = Flask(__name__, instance_relative_config=False)
    
    if os.environ.get("WORK_ENV") == "PROD" or config_name == "PROD":
        app_config = ProductionConfig
        
    if os.environ.get("WORK_ENV") == "TEST" or config_name == "TEST":
        app_config = TestingConfig

    else:
        app_config = DevelopmentConfig
    
    app.config.from_object(app_config) #Database location
    app.config.from_prefixed_env()
    celery_init_app(app)
    
    migrate = Migrate(app, db)
    assets = Environment()
    app.elasticsearch = Elasticsearch(app.config["ELASTICSEARCH_URL"])
    
    db.init_app(app) #: db init
    Bootstrap(app)
    migrate.init_app(app, db) #: migrate init
    assets.init_app(app) #: assets init
    mail.init_app(app) #: mail init
    cache.init_app(app) #: cache init
    ckeditor.init_app(app) #: ckeditor init
    moment.init_app(app) #: moment init
    
    with app.app_context():
        # import parts of application
        from shop.auth.routes import auth_bp
        from shop.oauth.oauth import github_bp
        from shop.home.routes import home_bp
        from shop.explore.routes import explore_bp
        from shop.account.routes import account_bp
        from shop.cart.routes import cart_bp
        from shop.orders.routes import order_bp
        from shop.products.routes import product_bp
        from shop.review.routes import review_bp
        from shop.contact.routes import contact_bp
        from shop.donate.routes import donate_bp
        
        from shop.api.routes import api_bp
        
        from shop.developers.routes import developers_bp
        from shop.investors.routes import investors_bp
        from shop.cookies.routes import cookies_bp
        from shop.privacy.routes import privacy_bp
        from shop.help.routes import help_bp
        
        # admin
        from shop.admin.routes import admin #UserView, RoleView, ArticleView, ContactView, SubscribeView
        
        # register blueprints
        app.register_blueprint(admin)
        app.register_blueprint(auth_bp)
        app.register_blueprint(github_bp)
        app.register_blueprint(account_bp)
        app.register_blueprint(home_bp)
        app.register_blueprint(explore_bp)
        app.register_blueprint(product_bp)
        app.register_blueprint(review_bp)
        app.register_blueprint(cart_bp)
        app.register_blueprint(order_bp)
        app.register_blueprint(contact_bp)
        app.register_blueprint(donate_bp)
        
        app.register_blueprint(api_bp)
        app.register_blueprint(developers_bp)
        app.register_blueprint(investors_bp)
        app.register_blueprint(privacy_bp)
        app.register_blueprint(cookies_bp)
        app.register_blueprint(help_bp)
        
        #admin
        """
        admin.add_view(UserView(User, db.session, menu_icon_type="glyph", menu_icon_value="glyphicon-user"))
        admin.add_view(RoleView(Role, db.session, menu_icon_type="glyph", menu_icon_value="glyphicon-lock"))
        admin.add_view(ProductView(Product, db.session, menu_icon_type="glyph", menu_icon_value="glyphicon-book"))
        admin.add_view(ContactView(Contact, db.session, menu_icon_type="glyph", menu_icon_value="glyphicon-envelope"))
        admin.add_view(SubscribeView(Subscribe, db.session, menu_icon_type="glyph", menu_icon_value="glyphicon-clock"))
        """
        
        
        # compile static assets
        compile_static_assets(assets)
        
        db.create_all()
        
        if not Role.query.filter_by(name="super-user").first():
            super_user = Role(name="super-user", desc="A super user have all access to system.")
            admin = Role(name="admin", desc="An admin have access to administration dashboard.")
            seller = Role(name="seller", desc="A seller has access to his/her products and he/she can edit them and create new products.")
            user = Role(name="user", desc="A user can only take a control of his or her account.")            
            
            db.session.add(super_user)   
            db.session.add(admin)
            db.session.add(seller)
            db.session.add(user)
            db.session.commit()
            
        if not User.query.filter_by(user_name="wizwolf", email="ishimweaimable03@gmail.com").first():
            super = Role.query.filter_by(name="super-user").first()
            admin = Role.query.filter_by(name="admin").first()
            seller = Role.query.filter_by(name="seller").first()
            user = Role.query.filter_by(name="user").first()
            
            roles = [super, admin, seller, user] #: roles
            
            super_ = User(
                user_name="wizwolf",
                name="ishimwe aimable",
                email="ishimweaimable03@gmail.com",
                my_password=generate_password_hash("wizwolf250", method='pbkdf2:sha256', salt_length=8),
                admin=True,
                phone="+250789688248",
            )
            
            db.session.add(super_)
            db.session.commit()
            print("\n")
            print("[*] Starting to register super user...")
            
            for role in roles:
                super_.roles.append(role)
                print(f"[*] Getting {role.name} role for super user...")  
                db.session.commit() 
                     
            print("[*] Super user created successfully! ") 
            print("[!] Hi, {}!".format(super_.user_name))  
            print("[!] You're welcomed to abord! ")   
        
        if not Category.query.all():
            clothing = Category(name="Clothing", description="Here we sell to you clothes wherever you are! ")
            electronic = Category(name="Electronics", description="Here we sell to you electronics wherever you are! ")
            food = Category(name="Food", description="Here we sell to you foods wherever you are! ")
            
            db.session.add(clothing) 
            db.session.add(electronic)
            db.session.add(food)    
            db.session.commit()
            
        if not Color.query.all():
            colors = ["black", "white", "red", "blue", "pink", "yellow", "green", "orange"]
            for color in colors:
                c = Color(name=color)
                db.session.add(c)
                db.session.commit()
                
        return app
        
        