from flask_login import current_user, UserMixin
from shop.utils.db import db
from datetime import datetime

from flask_dance.consumer.storage.sqla import OAuthConsumerMixin


class Role(db.Model):
    #: role model
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(), nullable=False, unique=True)
    desc = db.Column(db.String(), nullable=False)
    
    created_at = db.Column(db.DateTime(), default=datetime.utcnow())
    updated_at = db.Column(db.DateTime(), default=datetime.utcnow())
    

class Todo(db.Model):
    __tablename__ = 'todos'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    uid = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    
    created_at = db.Column(db.DateTime(), default=datetime.utcnow())
    updated_at = db.Column(db.DateTime(), default=datetime.utcnow())
    
class Review(db.Model):
    #: review model
    __tablename__ = "reviews"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    itemid = db.Column(db.Integer, db.ForeignKey("items.id"), nullable=False)
    uid = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    rating = db.Column(db.Integer, nullable=True)
    comment = db.Column(db.Text, nullable=False)
    
    #item = db.relationship("Item", backref=db.backref("reviews", lazy=True))
    
    created_at = db.Column(db.DateTime(), default=datetime.utcnow())

    
#: user roles
user_roles = db.Table("user_roles",
    db.Column('user_id', db.Integer(), db.ForeignKey('users.id')),
    db.Column('role_id', db.Integer(), db.ForeignKey('roles.id')))


#: user todos
user_todos = db.Table("user_todos",
    db.Column('user_id', db.Integer(), db.ForeignKey('users.id')),
    db.Column('todo_id', db.Integer(), db.ForeignKey('todos.id')))


#: item colors
item_colors = db.Table("item_colors",
    db.Column('item_id', db.Integer(), db.ForeignKey('items.id')),
    db.Column('color_id', db.Integer(), db.ForeignKey('colors.id')))


class Discount(db.Model):
    #: discount model
    __tablename__ = 'discounts'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    itemid = db.Column(db.Integer, db.ForeignKey("items.id"))
    name = db.Column(db.String(), nullable=False, unique=True)
    description = db.Column(db.String(), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    percent = db.Column(db.Float, nullable=False)
    
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    

class Image(db.Model):
    #: item image model 
    __tablename__ = 'images'
    id = db.Column(db.Integer, primary_key=True)
    itemid = db.Column(db.Integer, db.ForeignKey("items.id"), nullable=False)
    image = db.Column(db.String(), nullable=False)
   

class Color(db.Model):
    #: color model 
    __tablename__ = 'colors'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), nullable=True)
   

class Category(db.Model):
    #: category model
    __tablename__ = 'categories'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(), nullable=False)
    description = db.Column(db.Text, nullable=False) 
    
    
class Inventory(db.Model):
    #: inventory model 
    __tablename__ = 'inventories'
    id = db.Column(db.Integer, primary_key=True)
    #itemid = db.Column(db.Integer, db.ForeignKey("items.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False) 
    
    #item = db.relationship("Item", backref=db.backref("inventory", uselist=False))         


class User(UserMixin, db.Model):
    #: user model
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Text, nullable=False)
    user_name = db.Column(db.String(34), nullable=False)
    email = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(50), nullable=False)
    my_password = db.Column(db.String(250), nullable=False)
    admin = db.Column(db.Boolean, nullable=True, default=False)
    email_confirmed = db.Column(db.Boolean, nullable=True, default=False)
    cart = db.relationship('Cart', backref='buyer')
    orders = db.relationship("Order", backref='customer')
    #: avatar image
    avatar = db.Column(db.String(), nullable=False, default="blank_avatar.png")
    
    #: roles of user 
    roles = db.relationship(
        "Role", 
        secondary=user_roles, 
        backref=db.backref("roles", lazy="dynamic"),
    )
    
    #: user todos
    todos = db.relationship(
        "Todo", 
        secondary=user_todos, 
        backref=db.backref("todos", lazy="dynamic"),
    )
    
    created_at = db.Column(db.DateTime(), default=datetime.utcnow())
    updated_at = db.Column(db.DateTime(), default=datetime.utcnow())
    
    def add_to_cart(self, itemid, quantity):
        #: add to cart
        item = Cart.query.filter_by(itemid=itemid, uid=self.id).first()
        if item in self.cart:
            item.quantity += 1
            db.session.add(item)
            db.session.commit()
            
        else:
            item_to_add = Cart(itemid=itemid, uid=self.id, quantity=quantity)
            db.session.add(item_to_add)
            db.session.commit()

    def remove_from_cart(self, itemid, quantity):
        item_to_remove = Cart.query.filter_by(itemid=itemid, uid=self.id, quantity=quantity).first()
        db.session.delete(item_to_remove)
        db.session.commit()
        
    def increase_quantity(self, itemid, quantity=None):
        #: increase quantity
        item = Cart.query.filter_by(itemid=itemid, uid=self.id).first()
        if item in self.cart:
            if quantity is None:
                item.quantity += 1
                db.session.add(item)
                db.session.commit()
                
                return item.quantity
                
            else:
                item.quantity = quantity
                db.session.add(item)
                db.session.commit()   
                return item.quantity     

    def decrease_quantity(self, itemid, quantity=None):
        #: decrease quantity
        item = Cart.query.filter_by(itemid=itemid, uid=self.id).first()
        if item in self.cart:
            if quantity is None:
                if item.quantity > 1:
                    item.quantity -= 1
                    db.session.add(item)
                    db.session.commit()  
                    return item.quantity      
            else:
                item.quantity = quantity
                db.session.add(item)
                db.session.commit() 
                return item.quantity       

class OAuth(OAuthConsumerMixin, db.Model):
	user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
	user = db.relationship(User)
	
	
class Item(db.Model):
    #: item model
    __tablename__ = "items"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    inventory_id = db.Column(db.Integer, db.ForeignKey("inventories.id"), nullable=True)
    image = db.Column(db.String(250), nullable=False)
    details = db.Column(db.String(250), nullable=False)
    price_id = db.Column(db.String(250), nullable=False)
    orders = db.relationship("Ordered_item", backref="item")
    in_cart = db.relationship("Cart", backref="item")
    
    discount = db.relationship("Discount", backref="discount")
    
    reviews = db.relationship(
        "Review",
        backref="reviews",
    )
    
    colors = db.relationship(
        "Color",
        secondary=item_colors, 
        backref=db.backref("colors", lazy="dynamic"),
    )
    
    category = db.relationship(
        "Category",
        backref="category",
    )
    
    images = db.relationship(
        "Image",
        backref="images",
    )
    
    inventory = db.relationship(
        "Inventory",
        backref="inventory",
    )
    
    created_at = db.Column(db.DateTime(), default=datetime.utcnow())
    updated_at = db.Column(db.DateTime(), default=datetime.utcnow())


class Cart(db.Model):
    #: cart model
    __tablename__ = "cart"
    id = db.Column(db.Integer, primary_key=True)
    uid = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    itemid = db.Column(db.Integer, db.ForeignKey('items.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    
    created_at = db.Column(db.DateTime(), default=datetime.utcnow())
    updated_at = db.Column(db.DateTime(), default=datetime.utcnow())


class Order(db.Model):
    #: order model
    __tablename__ = "orders"
    id = db.Column(db.Integer, primary_key=True)
    uid = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    date = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(50), nullable=False)
    items = db.relationship("Ordered_item", backref="order")

    created_at = db.Column(db.DateTime(), default=datetime.utcnow())
    updated_at = db.Column(db.DateTime(), default=datetime.utcnow())


class Ordered_item(db.Model):
    #: ordered item model
    __tablename__ = "ordered_items"
    id = db.Column(db.Integer, primary_key=True)
    oid = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    itemid = db.Column(db.Integer, db.ForeignKey('items.id'), nullable=False)
    quantity = db.Column(db.Integer, db.ForeignKey('cart.quantity'), nullable=False)    
       
    created_at = db.Column(db.DateTime(), default=datetime.utcnow())
    updated_at = db.Column(db.DateTime(), default=datetime.utcnow())
    
    
class Contact(db.Model):
    #: contact
    __tablename__ = 'contacts'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(), nullable=False)
    email = db.Column(db.String(), nullable=False)
    subject = db.Column(db.String(), nullable=False)
    project_detail = db.Column(db.String(), nullable=False)
    
    created_at = db.Column(db.DateTime(), default=datetime.utcnow())
    updated_at = db.Column(db.DateTime(), default=datetime.utcnow())


class Subscribe(db.Model):
    #: subscribe model
    __tablename__ = "subscribers"     
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    email = db.Column(db.String(128), index=True, nullable=False)   
    
    
class Setting(db.Model):
    #: setting model
    __tablename__ = 'settings'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(), unique=True, nullable=False)
    value = db.Column(db.String(), nullable=False)
    description = db.Column(db.Text, nullable=False) 
    	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
  	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        