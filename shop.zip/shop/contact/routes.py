import datetime
from flask import Blueprint
from flask import url_for, redirect, render_template, request, session, abort, flash, Flask
from flask import current_app as app

from markupsafe import escape


contact_bp = Blueprint(
    'contact_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

@contact_bp.route("/contact/", methods=["GET"])
def contact():
    return render_template(
        "contact.html",
        title='Contact',
        subtitle="Contact us ",
        template="contact-template",
    )

