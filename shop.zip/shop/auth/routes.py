import os
import functools
from datetime import datetime
from flask import Blueprint
from flask import url_for, redirect, render_template, request, session, abort, flash, Flask
from flask import current_app as app
from flask_login import user_loaded_from_request, login_user, login_required, LoginManager, current_user, UserMixin, logout_user

#werkzeug
from werkzeug.security import generate_password_hash, check_password_hash
import werkzeug
from werkzeug.utils import secure_filename

from shop.models import User, Role

#database
from shop.utils.db import db

from markupsafe import escape

#: forms
from shop.forms import RegisterForm, LoginForm

from flask_dance.contrib.github import github

auth_bp = Blueprint(
    'auth_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

def login_required(func):
    @functools.wraps(func)
    def secure(*args, **kwargs):
        if "user_name" not in session:
            return redirect(url_for("auth_bp.login", next=request.url))
       
        return func(*args, **kwargs)
    
    return secure
        
login_manager = LoginManager(app)
login_manager.login_view = "auth_bp.login"
#: login_manager.message = "You need to login "

class UserLogin(UserMixin):
    pass     
     
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))
    

@auth_bp.route("/login", methods=['POST', 'GET'])
def login():
    
    form = LoginForm()
	
    if form.validate_on_submit():
        email = form.email.data
        user = User.query.filter_by(email=email).first() or User.query.filter_by(user_name=email).first()
        if user == None:
            flash(f'User with email {email} doesn\'t exist!<br> <a href={url_for("register")}>Register now!</a>', 'error')
            return redirect(url_for('auth_bp.login'))
        elif check_password_hash(user.my_password, form.password.data):
            login_user(user)
            session["profile-picture"] = user.avatar
            #: session["theme"] = "light"
            flash(f"You logged successfully!", 'success')
            return redirect(url_for('home_bp.index'))
        else:
            flash("Email and password incorrect!!", "error")
            return redirect(url_for('auth_bp.login'))
            
    return render_template("login.html", title="Login", form=form)

@auth_bp.route("/register", methods=['POST', 'GET'])
def register():
	if current_user.is_authenticated:
		return redirect(url_for('home_bp.index'))
		
	form = RegisterForm()
	if form.validate_on_submit():
		user = User.query.filter_by(email=form.email.data).first()
		if user:
			flash(f"User with email {user.email} already exists!!<br> <a href={url_for('login')}>Login now!</a>", "error")
			return redirect(url_for('auth_bp.register'))
		new_user = User(name=form.name.data,
						email=form.email.data,
						my_password=generate_password_hash(
									form.password.data,
									method='pbkdf2:sha256',
									salt_length=8),
						phone=form.phone.data)
		db.session.add(new_user)
		db.session.commit()
		# send_confirmation_email(new_user.email)
		flash('Thanks for registering! You may login now.', 'success')
		return redirect(url_for('auth_bp.login'))
		
	return render_template("register.html", title="Register", form=form)

@auth_bp.route('/confirm/<token>')
def confirm_email(token):
	try:
		confirm_serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
		email = confirm_serializer.loads(token, salt='email-confirmation-salt', max_age=3600)
	except:
		flash('The confirmation link is invalid or has expired.', 'error')
		return redirect(url_for('auth_bp.login'))
	user = User.query.filter_by(email=email).first()
	if user.email_confirmed:
		flash(f'Account already confirmed. Please login.', 'success')
	else:
		user.email_confirmed = True
		db.session.add(user)
		db.session.commit()
		flash('Email address successfully confirmed!', 'success')
	return redirect(url_for('auth_bp.login'))

@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    session.clear()
    return redirect(url_for('auth_bp.login'))

@auth_bp.route("/resend")
@login_required
def resend():
	send_confirmation_email(current_user.email)
	logout_user()
	flash('Confirmation email sent successfully.', 'success')
	return redirect(url_for('auth_bp.login'))

