import os
from flask import current_app as app
from flask_assets import Bundle

def compile_static_assets(assets):
    assets.auto_build = True
    assets.debug = True
    
    common_style_bundle = Bundle(
        'src/less/*.less',
        filters='less,cssmin',
        output='dist/css/style.css',
        extra={'rel' : 'stylesheet/less'})
        
    admin_style_bundle = Bundle(
        'admin_bp/less/admin.less',
        filters='less,cssmin',
        output='dist/css/admin.css',
        extra={'rel' : 'stylesheet/less'})   
        
    auth_style_bundle = Bundle(
        'auth_bp/less/auth.less',
        filters='less,cssmin',
        output='dist/css/auth.css',
        extra={'rel' : 'stylesheet/less'})
        
    account_style_bundle = Bundle(
        'account_bp/less/account.less',
        filters='less,cssmin',
        output='dist/css/account.css',
        extra={'rel' : 'stylesheet/less'})
        
    cart_style_bundle = Bundle(
        'cart_bp/less/cart.less',
        filters='less,cssmin',
        output='dist/css/cart.css',
        extra={'rel' : 'stylesheet/less'})
        
    contact_style_bundle = Bundle(
        'contact_bp/less/contact.less',
        filters='less,cssmin',
        output='dist/css/contact.css',
        extra={'rel' : 'stylesheet/less'})
        
    
                              
   #register assets        
    assets.register(
        'common_style_bundle',
        common_style_bundle,
    )
    
    assets.register(
        'admin_style_bundle',
        admin_style_bundle,
    )
        
    assets.register(
        'auth_style_bundle',
        auth_style_bundle,
    )
        
    assets.register(
        'account_style_bundle',
        account_style_bundle,
    )
        
    assets.register(
        'cart_style_bundle',
        cart_style_bundle,
    )
    
    assets.register(
        'contact_style_bundle',
        contact_style_bundle,
    )
        
                
    if os.environ.get('WORK_ENV') == 'DEV':
        admin_style_bundle.build()
        common_style_bundle.build()
        auth_style_bundle.build()
        account_style_bundle.build()
        cart_style_bundle.build()
        contact_style_bundle.build()
        
        
        
    return assets