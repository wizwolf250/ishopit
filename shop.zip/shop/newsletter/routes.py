import datetime
from flask import Blueprint
from flask import url_for, redirect, render_template, request, session, abort, flash, Flask
from flask import current_app as app

from markupsafe import escape
from shop.forms import SubscribeForm

newsletter_bp = Blueprint(
    'newsletter_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

@newsletter_bp.context_processor
def inject_year():
    current_year = datetime.datetime.now().year
    return dict(year=current_year)

# ... other routes and views

@newsletter_bp.route("/subscribe", methods=["POST"])
def subscribe():
    
    form = SubscribeForm()
    
    if form.validate_on_submit():
        
        return redirect(url_for("home_bp.index"))
    