import os
from flask_moment import Moment
from flask_mail import Mail
#from flask import current_app as app
from flask_caching import Cache
from celery import Celery, Task
from newsapi import NewsApiClient
from elasticsearch import Elasticsearch
from flask_ckeditor import CKEditor
from flask import Flask

#key = app.config["NEWS_API_SECRET"]

#news_api = NewsApiClient(api_key=key)

moment = Moment() #: moment
mail = Mail() #: mail
cache = Cache(config={"CACHE_TYPE" : "simple"})
ckeditor = CKEditor()


def celery_init_app(app: Flask) -> Celery:
    class FlaskTask(Task):
        def __call__(self, *args: object, **kwargs: object) -> object:
            with app.app_context():
                return self.run(*args, **kwargs)

    celery_app = Celery(app.name, task_cls=FlaskTask, broker=app.config["CELERY_BROKER_URL"], backend=app.config["CELERY_RESULT_BACKEND"])
    #: celery_app.config_from_object(app.config["CELERY"])
    #: celery_app.set_default()
    celery_app.conf.update(app.config)
    app.extensions["celery"] = celery_app
    return celery_app

