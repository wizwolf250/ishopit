import datetime
from flask import Blueprint
from flask import url_for, redirect, render_template, request, session, abort, flash, Flask
from flask import current_app as app

from markupsafe import escape
from shop.models import Item, Cart, Order, Review

from flask_login import current_user, login_required

from shop.forms import SubscribeForm


api_bp = Blueprint(
    'api_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

@api_bp.route("/api")
def api():
	subForm = SubscribeForm()
	return render_template("api.html", title="Api", subForm=subForm)
