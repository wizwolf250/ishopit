import os, stripe, json
from datetime import datetime
from flask import Blueprint
from flask import url_for, redirect, render_template, request, session, abort, flash, Flask
from flask import current_app as app
from itsdangerous import URLSafeTimedSerializer
from shop.funcs import mail, send_confirmation_email, fulfill_order
from markupsafe import escape
from flask_login import current_user, login_required

order_bp = Blueprint(
    'order_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

@order_bp.route('/orders')
@login_required
def orders():
	return render_template('orders.html', orders=current_user.orders, title="Orders")

# stripe stuffs
@order_bp.route('/payment_success')
def payment_success():
	return render_template('success.html')

@order_bp.route('/payment_failure')
def payment_failure():
	return render_template('failure.html')

@order_bp.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
	data = json.loads(request.form['price_ids'].replace("'", '"'))
	try:
		stripe.api_key = app.config["STRIPE_SECRET_KEY"]
		checkout_session = stripe.checkout.Session.create(
			client_reference_id=current_user.id,
			line_items=data,
			payment_method_types=[
			  'card',
			],
			mode='payment',
			success_url=url_for('order_bp.payment_success', _external=True),
			cancel_url=url_for('order_bp.payment_failure', _external=True),
		)
	except Exception as e:
		return str(e)
	return redirect(checkout_session.url, code=303)

@order_bp.route('/stripe-webhook', methods=['POST'])
def stripe_webhook():

	if request.content_length > 1024*1024:
		print("Request too big!")
		abort(400)

	payload = request.get_data()
	sig_header = request.env['HTTP_STRIPE_SIGNATURE']
	ENDPOINT_SECRET = app.config["ENDPOINT_SECRET"]
	event = None

	try:
		stripe.api_key = app.config["STRIPE_SECRET_KEY"]
		event = stripe.Webhook.construct_event(
		payload, sig_header, ENDPOINT_SECRET
		)
	except ValueError as e:
		# Invalid payload
		return {}, 400
	except stripe.error.SignatureVerificationError as e:
		# Invalid signature
		return {}, 400

	if event['type'] == 'checkout.session.completed':
		session = event['data']['object']

		# Fulfill the purchase...
		fulfill_order(session)

	# Passed signature verification
	return {}, 200