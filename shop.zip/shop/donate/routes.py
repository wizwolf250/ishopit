import datetime
from flask import Blueprint
from flask import url_for, redirect, render_template, request, session, abort, flash, Flask
from flask import current_app as app

from markupsafe import escape


donate_bp = Blueprint(
    'donate_bp', 
    __name__,
    template_folder='templates',
    static_folder='static',
)

@donate_bp.route("/donate/", methods=["GET"])
def donate():
    return render_template(
        "donate.html",
        title='Donate',
        subtitle="Donate",
        template="donate-template",
    )

