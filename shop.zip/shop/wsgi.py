from shop.app import create_app

if __name__ == '__main__':
    try:
        app = create_app()
        celery = app.extensions["celery"]
        #app.run(debug=True, reloader_type="stat")
        
    except Exception as e:
        print(str(e))