#oauth.py
import os
from flask import redirect, url_for
from flask_dance.contrib.github import make_github_blueprint, github
from flask_dance.contrib.facebook import make_facebook_blueprint, facebook
from flask_dance.contrib.google import make_google_blueprint, google

from flask_dance.consumer.storage.sqla import SQLAlchemyStorage
from shop.models import db, OAuth
from flask_login import current_user

#github
github_bp = make_github_blueprint(
	client_id="Ov23liLDcCtsmdi6omWU", 
	client_secret="e9319070d2086fee3698eff2a6e7cfd9c43756c0",
	storage=SQLAlchemyStorage(OAuth,
	db.session,
	user=current_user,
	user_required=False,
    )
)

#facebook
facebook_bp = make_facebook_blueprint(
	client_id="", 
	client_secret="",
	storage=SQLAlchemyStorage(OAuth,
	db.session,
	user=current_user,
	user_required=False,
    )
)

#google
google_bp = make_google_blueprint(
	client_id="", 
	client_secret="",
	storage=SQLAlchemyStorage(OAuth,
	db.session,
	user=current_user,
	user_required=False,
    )
)

		
@github_bp.route("/github_login")
def github_login():
    if not github.authorized:
        return redirect(url_for("github.authorized", _external=True))
    
    if github.authorized:
        res = github.session.get("/user")
        assert res.ok
        return "You are @{} on Github.".format(res.json()["login"])
    		
@github_bp.route("/github/authorized")
def github_authorized():
	return redirect(url_for("home_bp.index"))
